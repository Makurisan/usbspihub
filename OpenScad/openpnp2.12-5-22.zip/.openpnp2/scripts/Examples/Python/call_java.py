from javax.swing.JOptionPane import showMessageDialog

showMessageDialog(None, 'Hello!')
