from __future__ import absolute_import, division


def print_hello():
    print('Hello from a module!')
