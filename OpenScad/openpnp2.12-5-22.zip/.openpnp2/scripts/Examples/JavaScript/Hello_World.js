// Print Hello, OpenPnP to the console
print('Hello, OpenPnP!');
