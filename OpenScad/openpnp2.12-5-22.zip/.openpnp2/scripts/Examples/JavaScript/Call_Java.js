// Call into a Java class and show a message dialog
var optionPane = javax.swing.JOptionPane.showMessageDialog(null, 'Hello!');