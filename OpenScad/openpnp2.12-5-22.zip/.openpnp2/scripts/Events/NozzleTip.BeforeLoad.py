# get the marlin axis driver
driver = next(d for d in machine.getDrivers() if d.name == 'AxisDriver')

# disable endtops
driver.sendCommand("M121")
print("endstops disabled!")