# get the marlin axis driver
driver = next(d for d in machine.getDrivers() if d.name == 'AxisDriver')

# enable endtops
driver.sendCommand("M120")
print("endstops enabled!")